const express = require("express");
const twilio = require("twilio");
const path = require("path");

const app = express();
app.use(express.json({ limit: "12kb" }));
app.use(express.static(__dirname));

const required = ["TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_PHONE_NUMBER"];
const missing = required.filter((key) => !process.env[key]);
const client = missing.length ? null : twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

// Basic in-memory limit: max 5 calls per IP in a rolling 24-hour period.
// Use a persistent store / provider-side limits for a public production service.
const attempts = new Map();
function rateLimit(req, res, next) {
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const now = Date.now();
  const recent = (attempts.get(ip) || []).filter((t) => now - t < 24 * 60 * 60 * 1000);
  if (recent.length >= 5) {
    return res.status(429).json({ error: "Limit 5 połączeń na 24 godziny został wykorzystany." });
  }
  req.callIp = ip;
  req.recentAttempts = recent;
  next();
}

app.post("/api/call", rateLimit, async (req, res) => {
  if (!client) {
    return res.status(503).json({
      error: "Serwer nie jest skonfigurowany. Uzupełnij dane TWILIO_* w pliku .env i uruchom go ponownie."
    });
  }

  const { to, scenarioName, script } = req.body || {};
  if (typeof to !== "string" || !/^\+48\d{9}$/.test(to)) {
    return res.status(400).json({ error: "Podaj polski numer w formacie +48500100200." });
  }
  if (typeof script !== "string" || !script.trim() || script.length > 1800) {
    return res.status(400).json({ error: "Dialog jest pusty albo za długi (maks. 1800 znaków)." });
  }
  if (typeof scenarioName !== "string" || scenarioName.length > 100) {
    return res.status(400).json({ error: "Nieprawidłowa nazwa scenariusza." });
  }

  // Do not allow markup injection into TwiML.
  const escapeXml = (s) => s.replace(/[<>&'"]/g, (c) => ({
    "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
  }[c]));
  const safeTitle = escapeXml(scenarioName.trim());
  const safeScript = escapeXml(script.trim());
  const twiml = `<Response><Say language="pl-PL" voice="Polly.Agnieszka">Cześć! To automatyczny żart telefoniczny. Scenariusz: ${safeTitle}. ${safeScript} Koniec żartu. Miłego dnia!</Say><Hangup/></Response>`;

  try {
    const call = await client.calls.create({
      to,
      from: process.env.TWILIO_PHONE_NUMBER,
      twiml,
      timeout: 25
    });
    req.recentAttempts.push(Date.now());
    attempts.set(req.callIp, req.recentAttempts);
    return res.json({
      ok: true,
      callSid: call.sid,
      message: "Twilio przyjęło połączenie. Na koncie próbnym odbiorca musi być zweryfikowany w Twilio."
    });
  } catch (err) {
    console.error("Twilio call error:", err.code || "", err.message || "");
    return res.status(502).json({
      error: "Twilio nie wykonało połączenia. Sprawdź numer nadawcy, środki/konto próbne i czy numer odbiorcy jest zweryfikowany."
    });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true, twilioConfigured: Boolean(client) }));
app.get("/", (_req, res) => res.sendFile(path.join(__dirname, "Psikus_Premium_Twilio.html")));

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Psikus działa na http://localhost:${port}`);
  if (missing.length) console.warn("Brak konfiguracji:", missing.join(", "));
});
