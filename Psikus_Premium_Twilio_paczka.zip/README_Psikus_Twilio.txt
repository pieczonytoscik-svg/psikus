# Psikus Premium + Twilio

## Co jest w paczce
- `Psikus_Premium_Twilio.html` — odświeżony wygląd strony i przycisk prawdziwego połączenia.
- `server.js` — backend; sekrety Twilio pozostają na serwerze, nie w HTML.
- `package.json` — zależności.
- `.env.example` — wzór konfiguracji.

## Uruchomienie lokalne
1. Zainstaluj Node.js (wersja LTS).
2. Wypakuj ZIP do jednego folderu.
3. Skopiuj `.env.example` do pliku `.env`.
4. W panelu Twilio skopiuj Account SID i Auth Token do `.env`. W `TWILIO_PHONE_NUMBER` wpisz numer nadawcy, który rzeczywiście masz przypisany w Twilio.
5. W terminalu w tym folderze uruchom: `npm install`
6. Następnie: `npm start`
7. Otwórz `http://localhost:3000` (nie otwieraj samego pliku HTML przez dwuklik).

## Ważne
- Nigdy nie udostępniaj pliku `.env`, Auth Token ani kluczy.
- Konto próbne Twilio zwykle pozwala dzwonić tylko na numery, które zostały zweryfikowane w Twilio; mogą obowiązywać dodatkowe ograniczenia konta i regionu.
- Zwykłe połączenia telefoniczne mogą kosztować. Twilio nie gwarantuje bezpłatnej usługi przez długi czas.
- Używaj wyłącznie wobec osób, które zgodziły się na taki żart. Nie podszywaj się pod inne osoby ani numery.
- Backend ma prosty limit 5 połączeń/IP/24h; to ograniczenie demonstracyjne, nie pełne zabezpieczenie produkcyjne.
- Przed wystawieniem publicznie dodaj uwierzytelnianie i mocniejsze limity, aby nikt obcy nie wykorzystywał Twojego konta.
